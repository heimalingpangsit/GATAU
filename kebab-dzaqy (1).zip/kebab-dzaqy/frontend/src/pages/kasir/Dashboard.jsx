import { useAuth } from '../../context/AuthContext'
import { useNavigate } from 'react-router-dom'
import OrdersManage from '../shared/OrdersManage'

export default function KasirDashboard() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  return (
    <div className="pb-10">
      <header className="bg-ink text-paper px-4 pt-6 pb-4 flex items-center justify-between">
        <div>
          <p className="text-xs text-turmeric font-mono uppercase">Dashboard Kasir</p>
          <h1 className="font-display text-xl">Halo, {user?.username}</h1>
        </div>
        <button
          onClick={() => {
            logout()
            navigate('/')
          }}
          className="text-xs bg-paper/10 px-3 py-1.5 rounded-full"
        >
          Keluar
        </button>
      </header>

      <div className="px-4 mt-4">
        <OrdersManage />
      </div>
    </div>
  )
}
