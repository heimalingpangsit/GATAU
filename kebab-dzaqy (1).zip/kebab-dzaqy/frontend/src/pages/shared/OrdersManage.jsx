import { useEffect, useState } from 'react'
import apiClient from '../../api/client'

const STATUS_FLOW = ['pending_payment', 'paid', 'processing', 'ready', 'completed', 'cancelled']
const STATUS_LABEL = {
  pending_payment: 'Menunggu Bayar',
  paid: 'Sudah Dibayar',
  processing: 'Diproses',
  ready: 'Siap',
  completed: 'Selesai',
  cancelled: 'Dibatalkan',
  expired: 'Kadaluarsa',
}
const NEXT_STATUS = {
  paid: 'processing',
  processing: 'ready',
  ready: 'completed',
}

function formatRupiah(n) {
  return 'Rp' + n.toLocaleString('id-ID')
}

export default function OrdersManage() {
  const [orders, setOrders] = useState([])
  const [filter, setFilter] = useState('')

  async function load() {
    const res = await apiClient.get('/api/orders', {
      params: filter ? { status_filter: filter } : {},
    })
    setOrders(res.data)
  }
  useEffect(() => { load() }, [filter])

  async function advance(order) {
    const next = NEXT_STATUS[order.status]
    if (!next) return
    await apiClient.put(`/api/orders/${order.id}/status`, null, { params: { new_status: next } })
    load()
  }

  async function cancel(order) {
    if (!confirm('Batalkan pesanan ini?')) return
    await apiClient.put(`/api/orders/${order.id}/status`, null, { params: { new_status: 'cancelled' } })
    load()
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-2 overflow-x-auto">
        <button onClick={() => setFilter('')}
          className={`px-3 py-1 rounded-full text-xs font-semibold shrink-0 ${!filter ? 'bg-ink text-paper' : 'bg-ink/5'}`}>
          Semua
        </button>
        {STATUS_FLOW.map((s) => (
          <button key={s} onClick={() => setFilter(s)}
            className={`px-3 py-1 rounded-full text-xs font-semibold shrink-0 ${filter === s ? 'bg-ink text-paper' : 'bg-ink/5'}`}>
            {STATUS_LABEL[s]}
          </button>
        ))}
      </div>

      <div className="space-y-2">
        {orders.length === 0 && <p className="text-center text-ash text-sm py-8">Tidak ada pesanan.</p>}
        {orders.map((o) => (
          <div key={o.id} className="ticket-card border border-ink/10 p-3">
            <div className="flex justify-between items-start">
              <div>
                <p className="font-mono font-bold text-sm">{o.order_number}</p>
                <p className="text-xs text-ash">{o.customer_name} · {o.customer_whatsapp}</p>
                <p className="text-xs text-ash">{o.order_type === 'delivery' ? 'Diantar' : 'Ambil sendiri'}</p>
              </div>
              <span className="text-xs font-semibold px-2 py-1 rounded-full bg-ink/5">
                {STATUS_LABEL[o.status] || o.status}
              </span>
            </div>

            <div className="ticket-perforation my-2" />

            <div className="space-y-0.5">
              {o.items.map((it) => (
                <div key={it.menu_id} className="flex justify-between text-xs">
                  <span>{it.qty}× {it.name}</span>
                  <span className="font-mono">{formatRupiah(it.subtotal)}</span>
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center mt-2">
              <span className="font-mono font-bold text-sm">{formatRupiah(o.total)}</span>
              <div className="flex gap-2">
                {NEXT_STATUS[o.status] && (
                  <button onClick={() => advance(o)} className="text-xs font-semibold bg-herb text-white px-3 py-1.5 rounded-full">
                    Tandai {STATUS_LABEL[NEXT_STATUS[o.status]]}
                  </button>
                )}
                {['paid', 'processing'].includes(o.status) && (
                  <button onClick={() => cancel(o)} className="text-xs font-semibold text-sambal px-2">
                    Batal
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
