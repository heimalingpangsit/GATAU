import { useEffect, useState } from 'react'
import apiClient from '../../api/client'

const EMPTY_FORM = {
  code: '', type: 'percentage', value: 10, min_purchase: 0,
  max_discount: '', quota: '', active: true,
}

export default function VoucherManage() {
  const [vouchers, setVouchers] = useState([])
  const [form, setForm] = useState(EMPTY_FORM)
  const [editingId, setEditingId] = useState(null)
  const [showForm, setShowForm] = useState(false)

  async function load() {
    const res = await apiClient.get('/api/vouchers')
    setVouchers(res.data)
  }
  useEffect(() => { load() }, [])

  function startCreate() {
    setForm(EMPTY_FORM)
    setEditingId(null)
    setShowForm(true)
  }

  async function submit(e) {
    e.preventDefault()
    const payload = {
      ...form,
      value: Number(form.value),
      min_purchase: Number(form.min_purchase) || 0,
      max_discount: form.max_discount ? Number(form.max_discount) : null,
      quota: form.quota ? Number(form.quota) : null,
    }
    if (editingId) {
      await apiClient.put(`/api/vouchers/${editingId}`, payload)
    } else {
      await apiClient.post('/api/vouchers', payload)
    }
    setShowForm(false)
    load()
  }

  async function remove(id) {
    if (!confirm('Hapus voucher ini?')) return
    await apiClient.delete(`/api/vouchers/${id}`)
    load()
  }

  return (
    <div className="space-y-3">
      <button onClick={startCreate} className="w-full bg-ink text-paper text-sm font-semibold py-2 rounded-lg">
        + Tambah Voucher
      </button>

      {showForm && (
        <form onSubmit={submit} className="ticket-card border border-ink/10 p-4 space-y-2">
          <input required placeholder="Kode voucher (mis. DZAQY10)" value={form.code}
            onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
            className="w-full border border-ink/15 rounded px-2 py-1.5 text-sm font-mono" />
          <div className="flex gap-2">
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}
              className="flex-1 border border-ink/15 rounded px-2 py-1.5 text-sm">
              <option value="percentage">Persentase (%)</option>
              <option value="fixed">Potongan Tetap (Rp)</option>
            </select>
            <input required type="number" placeholder="Nilai" value={form.value}
              onChange={(e) => setForm({ ...form, value: e.target.value })}
              className="flex-1 border border-ink/15 rounded px-2 py-1.5 text-sm" />
          </div>
          <div className="flex gap-2">
            <input type="number" placeholder="Min. belanja" value={form.min_purchase}
              onChange={(e) => setForm({ ...form, min_purchase: e.target.value })}
              className="flex-1 border border-ink/15 rounded px-2 py-1.5 text-sm" />
            <input type="number" placeholder="Maks. diskon (opsional)" value={form.max_discount}
              onChange={(e) => setForm({ ...form, max_discount: e.target.value })}
              className="flex-1 border border-ink/15 rounded px-2 py-1.5 text-sm" />
          </div>
          <input type="number" placeholder="Kuota (opsional, kosongkan = tanpa batas)" value={form.quota}
            onChange={(e) => setForm({ ...form, quota: e.target.value })}
            className="w-full border border-ink/15 rounded px-2 py-1.5 text-sm" />
          <label className="flex items-center gap-1 text-sm">
            <input type="checkbox" checked={form.active}
              onChange={(e) => setForm({ ...form, active: e.target.checked })} />
            Aktif
          </label>
          <div className="flex gap-2">
            <button type="submit" className="flex-1 bg-sambal text-white text-sm font-semibold py-2 rounded-lg">
              Simpan
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="px-4 text-sm text-ash">
              Batal
            </button>
          </div>
        </form>
      )}

      <div className="space-y-2">
        {vouchers.map((v) => (
          <div key={v.id} className="ticket-card border border-ink/10 p-3 flex items-center justify-between">
            <div>
              <p className="text-sm font-mono font-bold">{v.code} {!v.active && <span className="text-sambal text-xs">(nonaktif)</span>}</p>
              <p className="text-xs text-ash">
                {v.type === 'percentage' ? `${v.value}%` : `Rp${v.value.toLocaleString('id-ID')}`}
                {' · '}terpakai {v.used_count}{v.quota ? `/${v.quota}` : ''}
              </p>
            </div>
            <button onClick={() => remove(v.id)} className="text-sambal text-xs font-semibold">Hapus</button>
          </div>
        ))}
      </div>
    </div>
  )
}
