import { useEffect, useState } from 'react'
import apiClient from '../../api/client'

const EMPTY_FORM = {
  name: '', description: '', category: 'kebab', price: 0,
  image_url: '', is_available: true, is_promo: false,
}

function formatRupiah(n) {
  return 'Rp' + n.toLocaleString('id-ID')
}

export default function MenuManage() {
  const [menu, setMenu] = useState([])
  const [form, setForm] = useState(EMPTY_FORM)
  const [editingId, setEditingId] = useState(null)
  const [showForm, setShowForm] = useState(false)

  async function load() {
    const res = await apiClient.get('/api/menu')
    setMenu(res.data)
  }
  useEffect(() => { load() }, [])

  function startCreate() {
    setForm(EMPTY_FORM)
    setEditingId(null)
    setShowForm(true)
  }

  function startEdit(item) {
    setForm(item)
    setEditingId(item.id)
    setShowForm(true)
  }

  async function submit(e) {
    e.preventDefault()
    const payload = { ...form, price: Number(form.price) }
    if (editingId) {
      await apiClient.put(`/api/menu/${editingId}`, payload)
    } else {
      await apiClient.post('/api/menu', payload)
    }
    setShowForm(false)
    load()
  }

  async function remove(id) {
    if (!confirm('Hapus menu ini?')) return
    await apiClient.delete(`/api/menu/${id}`)
    load()
  }

  return (
    <div className="space-y-3">
      <button onClick={startCreate} className="w-full bg-ink text-paper text-sm font-semibold py-2 rounded-lg">
        + Tambah Menu
      </button>

      {showForm && (
        <form onSubmit={submit} className="ticket-card border border-ink/10 p-4 space-y-2">
          <input required placeholder="Nama menu" value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full border border-ink/15 rounded px-2 py-1.5 text-sm" />
          <textarea placeholder="Deskripsi" value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="w-full border border-ink/15 rounded px-2 py-1.5 text-sm" />
          <div className="flex gap-2">
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
              className="flex-1 border border-ink/15 rounded px-2 py-1.5 text-sm">
              <option value="kebab">Kebab</option>
              <option value="minuman">Minuman</option>
              <option value="snack">Snack</option>
            </select>
            <input required type="number" placeholder="Harga" value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })}
              className="flex-1 border border-ink/15 rounded px-2 py-1.5 text-sm" />
          </div>
          <input placeholder="URL gambar (opsional)" value={form.image_url || ''}
            onChange={(e) => setForm({ ...form, image_url: e.target.value })}
            className="w-full border border-ink/15 rounded px-2 py-1.5 text-sm" />
          <div className="flex gap-4 text-sm">
            <label className="flex items-center gap-1">
              <input type="checkbox" checked={form.is_available}
                onChange={(e) => setForm({ ...form, is_available: e.target.checked })} />
              Tersedia
            </label>
            <label className="flex items-center gap-1">
              <input type="checkbox" checked={form.is_promo}
                onChange={(e) => setForm({ ...form, is_promo: e.target.checked })} />
              Promo
            </label>
          </div>
          <div className="flex gap-2">
            <button type="submit" className="flex-1 bg-sambal text-white text-sm font-semibold py-2 rounded-lg">
              Simpan
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="px-4 text-sm text-ash">
              Batal
            </button>
          </div>
        </form>
      )}

      <div className="space-y-2">
        {menu.map((item) => (
          <div key={item.id} className="ticket-card border border-ink/10 p-3 flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold">{item.name} {!item.is_available && <span className="text-sambal text-xs">(habis)</span>}</p>
              <p className="text-xs text-ash font-mono">{formatRupiah(item.price)} · {item.category}</p>
            </div>
            <div className="flex gap-2 text-xs">
              <button onClick={() => startEdit(item)} className="text-herb font-semibold">Edit</button>
              <button onClick={() => remove(item.id)} className="text-sambal font-semibold">Hapus</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
