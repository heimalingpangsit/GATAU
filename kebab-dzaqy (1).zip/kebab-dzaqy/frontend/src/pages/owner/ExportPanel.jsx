const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

export default function ExportPanel() {
  function download(path) {
    const token = localStorage.getItem('kebab_dzaqy_token')
    // File download langsung dibuka di tab baru dengan token sebagai query
    // tidak didukung backend saat ini (backend pakai Bearer header), jadi
    // kita fetch manual lalu trigger download di browser.
    fetch(`${BASE_URL}${path}`, { headers: { Authorization: `Bearer ${token}` } })
      .then((res) => res.blob())
      .then((blob) => {
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = path.split('/').pop()
        a.click()
        URL.revokeObjectURL(url)
      })
  }

  return (
    <div className="space-y-3">
      <p className="text-sm text-ash">Unduh laporan riwayat pesanan.</p>
      <button onClick={() => download('/api/export/orders.csv')} className="w-full bg-ink/5 py-3 rounded-lg text-sm font-semibold">
        Unduh CSV
      </button>
      <button onClick={() => download('/api/export/orders.xlsx')} className="w-full bg-ink/5 py-3 rounded-lg text-sm font-semibold">
        Unduh Excel (.xlsx)
      </button>
      <button onClick={() => download('/api/export/orders.pdf')} className="w-full bg-ink/5 py-3 rounded-lg text-sm font-semibold">
        Unduh PDF
      </button>
    </div>
  )
}
