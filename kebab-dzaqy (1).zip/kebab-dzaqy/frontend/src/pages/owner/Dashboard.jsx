import { useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { useNavigate } from 'react-router-dom'
import Overview from './Overview'
import MenuManage from './MenuManage'
import VoucherManage from './VoucherManage'
import BannerManage from './BannerManage'
import OrdersManage from '../shared/OrdersManage'
import ExportPanel from './ExportPanel'

const TABS = [
  { key: 'overview', label: 'Ringkasan' },
  { key: 'orders', label: 'Pesanan' },
  { key: 'menu', label: 'Menu' },
  { key: 'voucher', label: 'Voucher' },
  { key: 'banner', label: 'Banner' },
  { key: 'export', label: 'Export' },
]

export default function OwnerDashboard() {
  const [tab, setTab] = useState('overview')
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  return (
    <div className="pb-10">
      <header className="bg-ink text-paper px-4 pt-6 pb-4 flex items-center justify-between">
        <div>
          <p className="text-xs text-turmeric font-mono uppercase">Dashboard Owner</p>
          <h1 className="font-display text-xl">Halo, {user?.username}</h1>
        </div>
        <button
          onClick={() => {
            logout()
            navigate('/')
          }}
          className="text-xs bg-paper/10 px-3 py-1.5 rounded-full"
        >
          Keluar
        </button>
      </header>

      <div className="flex gap-1 overflow-x-auto px-4 mt-4">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold shrink-0 ${
              tab === t.key ? 'bg-sambal text-white' : 'bg-ink/5 text-ink'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="px-4 mt-4">
        {tab === 'overview' && <Overview />}
        {tab === 'orders' && <OrdersManage />}
        {tab === 'menu' && <MenuManage />}
        {tab === 'voucher' && <VoucherManage />}
        {tab === 'banner' && <BannerManage />}
        {tab === 'export' && <ExportPanel />}
      </div>
    </div>
  )
}
