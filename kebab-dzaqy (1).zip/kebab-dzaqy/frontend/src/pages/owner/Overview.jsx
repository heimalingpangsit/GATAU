import { useEffect, useState } from 'react'
import apiClient from '../../api/client'

function formatRupiah(n) {
  return 'Rp' + (n || 0).toLocaleString('id-ID')
}

export default function Overview() {
  const [summary, setSummary] = useState(null)
  const [bestSellers, setBestSellers] = useState([])

  useEffect(() => {
    async function load() {
      const [sRes, bRes] = await Promise.all([
        apiClient.get('/api/dashboard/summary'),
        apiClient.get('/api/dashboard/best-sellers'),
      ])
      setSummary(sRes.data)
      setBestSellers(bRes.data)
    }
    load()
  }, [])

  if (!summary) return <p className="text-ash text-sm">Memuat…</p>

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="ticket-card border border-ink/10 p-4">
          <p className="text-xs text-ash">Pesanan Hari Ini</p>
          <p className="font-display text-2xl mt-1">{summary.today_order_count}</p>
        </div>
        <div className="ticket-card border border-ink/10 p-4">
          <p className="text-xs text-ash">Omzet Hari Ini</p>
          <p className="font-display text-lg mt-1 font-mono">{formatRupiah(summary.today_revenue)}</p>
        </div>
        <div className="ticket-card border border-ink/10 p-4">
          <p className="text-xs text-ash">Total Pesanan</p>
          <p className="font-display text-2xl mt-1">{summary.total_orders_all_time}</p>
        </div>
        <div className="ticket-card border border-ink/10 p-4">
          <p className="text-xs text-ash">Menunggu Bayar</p>
          <p className="font-display text-2xl mt-1 text-turmeric">{summary.pending_payment_count}</p>
        </div>
      </div>

      <div className="ticket-card border border-ink/10 p-4">
        <p className="text-sm font-semibold mb-2">Menu Terlaris</p>
        {bestSellers.length === 0 && <p className="text-xs text-ash">Belum ada data.</p>}
        <div className="space-y-1">
          {bestSellers.map((b, i) => (
            <div key={b.name} className="flex justify-between text-sm">
              <span>{i + 1}. {b.name}</span>
              <span className="font-mono text-ash">{b.qty_sold}x</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
