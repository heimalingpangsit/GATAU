import { useEffect, useState } from 'react'
import apiClient from '../../api/client'

const EMPTY_FORM = { title: '', image_url: '', link_url: '', active: true, order: 0 }

export default function BannerManage() {
  const [banners, setBanners] = useState([])
  const [form, setForm] = useState(EMPTY_FORM)
  const [showForm, setShowForm] = useState(false)

  async function load() {
    const res = await apiClient.get('/api/banners', { params: { active_only: false } })
    setBanners(res.data)
  }
  useEffect(() => { load() }, [])

  async function submit(e) {
    e.preventDefault()
    await apiClient.post('/api/banners', { ...form, order: Number(form.order) })
    setShowForm(false)
    setForm(EMPTY_FORM)
    load()
  }

  async function remove(id) {
    if (!confirm('Hapus banner ini?')) return
    await apiClient.delete(`/api/banners/${id}`)
    load()
  }

  return (
    <div className="space-y-3">
      <button onClick={() => setShowForm(true)} className="w-full bg-ink text-paper text-sm font-semibold py-2 rounded-lg">
        + Tambah Banner
      </button>

      {showForm && (
        <form onSubmit={submit} className="ticket-card border border-ink/10 p-4 space-y-2">
          <input required placeholder="Judul banner" value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="w-full border border-ink/15 rounded px-2 py-1.5 text-sm" />
          <input required placeholder="URL gambar" value={form.image_url}
            onChange={(e) => setForm({ ...form, image_url: e.target.value })}
            className="w-full border border-ink/15 rounded px-2 py-1.5 text-sm" />
          <input placeholder="Link tujuan (opsional)" value={form.link_url}
            onChange={(e) => setForm({ ...form, link_url: e.target.value })}
            className="w-full border border-ink/15 rounded px-2 py-1.5 text-sm" />
          <input type="number" placeholder="Urutan tampil" value={form.order}
            onChange={(e) => setForm({ ...form, order: e.target.value })}
            className="w-full border border-ink/15 rounded px-2 py-1.5 text-sm" />
          <div className="flex gap-2">
            <button type="submit" className="flex-1 bg-sambal text-white text-sm font-semibold py-2 rounded-lg">
              Simpan
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="px-4 text-sm text-ash">
              Batal
            </button>
          </div>
        </form>
      )}

      <div className="space-y-2">
        {banners.map((b) => (
          <div key={b.id} className="ticket-card border border-ink/10 p-3 flex items-center justify-between gap-3">
            <img src={b.image_url} alt={b.title} className="w-16 h-10 object-cover rounded" />
            <div className="flex-1">
              <p className="text-sm font-semibold">{b.title}</p>
              <p className="text-xs text-ash">{b.active ? 'Aktif' : 'Nonaktif'}</p>
            </div>
            <button onClick={() => remove(b.id)} className="text-sambal text-xs font-semibold">Hapus</button>
          </div>
        ))}
      </div>
    </div>
  )
}
